package net.phpTravels.utility;

public class Current {

	
		   public static void main(String[] argv) throws Exception {
		      String currentDirectory = System.getProperty("user.dir");
		      System.out.println("The current working directory is " + currentDirectory);
		   }
}
