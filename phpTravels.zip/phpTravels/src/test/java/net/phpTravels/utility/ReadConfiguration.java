package net.phpTravels.utility;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ReadConfiguration {
		
		static Properties prop;

		public ReadConfiguration() {
			File src = new File("./configuration.properties");
			FileInputStream fis;
			try {
				fis = new FileInputStream(src);
				prop = new Properties();
				prop.load(fis);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public static String readChromePath() {
			String path = prop.getProperty("chromePath");
			return path;
		}

		public static String readApplicatonUrl() {
			String appurl = prop.getProperty("webUrl");
			return appurl;
		}

		
		public static String readExcelPath() {
			String excelPath = prop.getProperty("excelPath");
			return excelPath;
		}

		public String readEmailId() {
			String emailId = prop.getProperty("EmailId");
			return emailId;
		}

		public String readPassword() {
			String password = prop.getProperty("password");
			return password;
		}
		
		
	}


