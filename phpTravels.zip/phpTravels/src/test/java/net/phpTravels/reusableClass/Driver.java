package net.phpTravels.reusableClass;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;

import com.google.common.io.Files;

import net.phpTravels.HomePageConstants.HomePageConstants;
import net.phpTravels.utility.ExtentReport;
import net.phpTravels.utility.PdfUtility;
import net.phpTravels.utility.ReadConfiguration;
import net.phpTravels.utility.ReadExcel;

@Listeners(ExtentReport.class)

public class Driver {
public static WebDriver driver;
	
	ReadConfiguration configuration = new ReadConfiguration();
	String chromePath = ReadConfiguration.readChromePath();
	protected String applicationUrl = ReadConfiguration.readApplicatonUrl();
	protected List<String> resultList = new ArrayList<String>();
	PdfUtility PdfUtility = new PdfUtility();
	
	public Driver() {
		super();
	}
	
	private ChromeOptions getChromeOptions() {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("disable-infobars");
		return options;
	}
	
	@BeforeSuite
	public void exectutionStarted() {
		System.out.println("phpTravels Demo");
	}
	@BeforeTest
	public void OpenBrowser() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", chromePath);
		driver = new EventFiringWebDriver(new ChromeDriver(getChromeOptions()));
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get(applicationUrl);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		
	
	}
	
	
	public void GetTile() {
		HomePageConstants home = PageFactory.initElements(Driver.driver, HomePageConstants.class);
		//HomePageConstants home = new HomePageConstants(driver);
		home.GetTitleValidate();
	}
	
	
	
	@AfterTest
	public void CloseBrowser() throws IOException, COSVisitorException {
		
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
		// add time stamp to the resultList
		resultList.add("Test Ends: " + timeStamp);
		// write the test result pdf file with file name TestResult
		PdfUtility.writeTestResultsToPdfFile("./pdfreports/TestResult" + timeStamp + ".pdf", resultList);
		
	}
	
	@AfterTest
	public void closeBrowser() {
		driver.close();
	}

	
	@DataProvider(name = "SignUpDetailsData")
	public Object[][] getData() throws Exception {
		String path = ReadConfiguration.readExcelPath();
		System.out.println(path);
		int rowNum = ReadExcel.getRowCount(path, "Sheet1");
		int colNum = ReadExcel.getCellCount(path, "Sheet1", 1);
		Object loginData[][] = new Object[rowNum][colNum];

		for (int i = 1; i <= rowNum; i++) {
			for (int j = 0; j < colNum; j++) {
				loginData[i - 1][j] = ReadExcel.getCellData(path, "Sheet1", i, j);
			}
		}

		return loginData;
	}

	@AfterSuite
	public void enOfTheExecution() {
		System.out.println("Execution Completed");
	}
	
	@BeforeClass
	public void beforclass()
	{
		
	}
	
	@AfterClass
	public void afterclass()
	{
		
	}
	
	@AfterMethod()	
	public void recordFailure(ITestResult result){
        if(ITestResult.FAILURE == result.getStatus())
        {
        	TakesScreenshot camera = (TakesScreenshot)driver;
            File screenshot = camera.getScreenshotAs(OutputType.FILE);
            try{
                Files.move(screenshot, new File("screenshotFailed/" + result.getName() + ".png"));
            }catch(IOException e){
                e.printStackTrace();
            }
        }
        else if (ITestResult.SUCCESS == result.getStatus()){
        	TakesScreenshot camera = (TakesScreenshot)driver;
            File screenshot = camera.getScreenshotAs(OutputType.FILE);
            try{
                Files.move(screenshot, new File("screenshotPassed/" + result.getName() + ".png"));
            }catch(IOException e){
                e.printStackTrace();
            }
        }
    }
	
		
		
	


}

