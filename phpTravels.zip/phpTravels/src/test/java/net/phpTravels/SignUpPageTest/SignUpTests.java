package net.phpTravels.SignUpPageTest;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;


import net.phpTravels.HomePageConstants.HomePageConstants;
import net.phpTravels.SignUpPageConstants.SignUpPageConstants;
import net.phpTravels.reusableClass.Driver;
import net.phpTravels.utility.Log;
import net.phpTravels.utility.ReadConfiguration;

public class SignUpTests extends Driver {
	
	
	ReadConfiguration configuration = new ReadConfiguration();
	
	public SignUpTests() {
		super();
		
	}
	//Below test will take the data using data Provider
	@Test (dataProvider ="SignUpDetailsData")
	public void VerifySignUp(String firstName, String lastName, String mobileNumber, String email, String password, String confirmPassword) {
		
	HomePageConstants home = PageFactory.initElements(Driver.driver, HomePageConstants.class);
	home.MyAccountDropdownValidation();
	resultList.add("----------------------------TC-5: Navigating to sign Up page screen ---------------------------");
	resultList.add("----------Step 1, Clicking on My Account dropdown ------------");
	Log.info("Successfully clicked on My Account dropdown");
	SignUpPageConstants signUp = PageFactory.initElements(Driver.driver, SignUpPageConstants.class);
	
	signUp.clickSignUp();
	resultList.add("1, Clicked on Sign Up Menu");
	Log.info("Successfully clicked on Sign Up Menu action button");
	signUp.enterFirstName(firstName);
	resultList.add("2, Entered FirstName");
	Log.info("Successfully entered firstname");
	signUp.enterLastName(lastName);
	resultList.add("3, Entered LastName");
	Log.info("Successfully entered lastname");
	signUp.enterMobileNumber(mobileNumber);
	resultList.add("4, Entered MobileNumber");
	Log.info("Successfully entered mobilenumber");
	signUp.enterEmail(email);
	resultList.add("5, Entered Email");
	Log.info("Successfully entered email");
	signUp.enterPassword(password);
	resultList.add("6, Entered Password");
	Log.info("Successfully entered password");
	signUp.enterConfirmPassword(confirmPassword);
	resultList.add("7, Entered ConfirmPassword");
	Log.info("Successfully entered confirmpassword");
	signUp.clickSignUpButton();
	resultList.add("8, Clicked on SignUp button");
	Log.info("sign Up successful");
	}
}
