package net.phpTravels.LoginPageTests;



import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;


import net.phpTravels.HomePageConstants.HomePageConstants;
import net.phpTravels.LoginPageConstants.LoginPageConstants;
import net.phpTravels.reusableClass.Driver;
import net.phpTravels.utility.Log;
import net.phpTravels.utility.ReadConfiguration;


public class LoginPageTests extends Driver {

	ReadConfiguration configuration = new ReadConfiguration();
	String emailId = configuration.readEmailId();
	String password = configuration.readPassword();
	
	
	public LoginPageTests() {
		super();
	}

	//This test is to verify the Invalid Email Id or Password error message
	@Test (priority = 1)
	public void LoginTestFailure() throws InterruptedException  {		
		HomePageConstants home = PageFactory.initElements(Driver.driver, HomePageConstants.class);
		home.MyAccountDropdownValidation();	
		resultList.add("----------------------------TC-1: Navigating to Login page screen and verifying the invalid credentials ---------------------------");
		resultList.add("----------Step 1, Clicking on My Account dropdown ------------");
		Log.info("Successfully clicked on My Account dropdown");
		LoginPageConstants login = PageFactory.initElements(Driver.driver, LoginPageConstants.class);		
		home.LoginMenuClickValidate();
		resultList.add("1, Clicked on Login Menu");
		Log.info("Successfully clicked on Login Menu action button");

		
		//When both Email and Pass are invalid
		login.emailFieldValidation("barathjas48@gamil.com");
		Log.info("Entered Email Id");
		login.passwordFieldValidtion("password");
		resultList.add("2, successfully entered Email and Password");
		Log.info("Entered Password");
		Thread.sleep(1000);
		login.loginButtonValidation();	
		resultList.add("3, Successfully clicked on Login Button");
		Log.info("Clicked on Login Button");
		Assert.assertEquals(login.errorTextValidte(), "Invalid Email or Password", "Error Does not Match");
		resultList.add("4, Error Message validation is successful");
		Log.info("Error Message is shown");
		
		
		//When Invalid Email Id and valid password is entered	
		login.clearEmailFields();
		Log.info("Cleared entered Email Id");
		login.emailFieldValidation("barath4303@gmail");	
		Log.info("Entered Email Id");
		login.clearPasswordFields();
		Log.info("Cleared entered Password");
		
		login.passwordFieldValidtion(password);	
		resultList.add("5, successfully entered Email and Password");
		Log.info("Entered Password");
		
		login.loginButtonValidation();
		resultList.add("6, Successfully clicked on Login Button");
		Log.info("Clicked on Login Button");
		Assert.assertEquals(login.errorTextValidte(), "Invalid Email or Password", "Error Does not Match");
		resultList.add("7, Error Message validation is successful");
		Log.info("Error Message is shown");
		
		//When valid Email Id and Invalid Password is entered		
		login.clearEmailFields();	
		Log.info("Cleared entered Email Id");
		login.emailFieldValidation(emailId);
		Log.info("Entered Email Id");
		login.clearPasswordFields();	
		Log.info("Cleared entered Password");
		login.passwordFieldValidtion("password@11");
		resultList.add("8, successfully entered Email and Password");
		Log.info("Entered Password");
		login.loginButtonValidation();
		resultList.add("9, Successfully clicked on Login Button");
		Log.info("Clicked on Login Button");
		Assert.assertEquals(login.errorTextValidte(), "Invalid Email or Password", "Error Does not Match");
		resultList.add("10, Error Message validation is successful");
		Log.info("Error Message is shown");
			
	}
	
	// This Tests validates the successful login
	 @Test (priority = 2)
	 public void LoginTestSuccess()   {
		 
		 
		 
		 HomePageConstants home = PageFactory.initElements(Driver.driver, HomePageConstants.class);
			
			//HomePageConstants home = new HomePageConstants(driver);
			home.MyAccountDropdownValidation();
			resultList.add("----------------------------TC-2: Navigating to Login page screen and verifying the Successful Login ---------------------------");
			resultList.add("----------Step 1, Clicking on My Account dropdown ------------");
			Log.info("Successfully clicked on My Account dropdown");
			
			LoginPageConstants login = PageFactory.initElements(Driver.driver, LoginPageConstants.class);
			//HomePageConstants home = PageFactory.initElements(Driver.driver, HomePageConstants.class);
			
			home.LoginMenuClickValidate();
			resultList.add("1, Clicked on Login Menu");
			Log.info("Successfully clicked on Login Menu action button");
			
			login.emailFieldValidation(emailId);
			Log.info("Entered Email Id");
			
			login.passwordFieldValidtion(password);
			Log.info("Entered Password");
			
			login.loginButtonValidation();
			resultList.add("2, Successfully clicked on Login Button");
			Log.info("Clicked on Login Button");
			
			Assert.assertEquals(login.loginSuccessValidation(), "Hi, Demo User", "Error Does not Match"); 
			resultList.add("3, After Login, verying the Welcome text");
			Log.info("Welcome Message is shown");
			
			
	 }
	
	 // This test is to Book a Flight
	 @Test (dependsOnMethods = {"LoginTestSuccess"})
	 public void BookFlight() throws InterruptedException {
		 
		
		 LoginPageConstants login = PageFactory.initElements(Driver.driver, LoginPageConstants.class);
		 
		 login.ClickHomeButton();
		 	resultList.add("----------------------------TC-3: Booking a Flight ---------------------------");
		 	resultList.add("4, After Login, Successfully clicked on Home button");
			Log.info("Home button is clicked");
		 
		 login.clickHotelsMenu();		 
		 login.flightMenuClick();
		 resultList.add("5, Successfully clicked on Flight Menu");
		Log.info("Flight Menu button is clicked");
		 Thread.sleep(3000);	
		
		 login.clickSearchButton();
		 resultList.add("6, Clicking on Search button, with default values");
		 Log.info("Successfully clicked on search button with defalt values");
		
		 login.clickBook();
		 resultList.add("7, Clicking on First Book button in the list");
		 Log.info("Successfully clicked on Book button");
		
		 Thread.sleep(3000);
		 login.ClickConfirmBooking();
		 resultList.add("8, Successfully clicked on ConfirmBooking Button");
		 Log.info("Successfully clicked on confirm Booking button");
		
		 login.ClickPayOnArrival();
		 resultList.add("9, Successfully Selected Pay On Arrival button");
		 Log.info("Successfully clicked on Pay on Arrival buttnon");
		
		 login.clickToAccept();
		 resultList.add("10, Successfully accepted the confirmation popup after clicking on Pay on Arrival button");
		 Log.info("Accepted the confirmation popup");
		
		 Assert.assertEquals(login.GetBookingStatus(), "Your booking status is Reserved", "Does not match");
		 resultList.add("11, Successfully verified the success message");
		 Log.info("Booking Resevered Message is shown");
	 }
	 
	 @Test (dependsOnMethods = {"LoginTestSuccess"})
	 public void VerifyLogout() {
		 LoginPageConstants login = PageFactory.initElements(Driver.driver, LoginPageConstants.class);
		 login.clickLogoutButton();
		 resultList.add("----------------------------TC-4: Logout from the application after Login ---------------------------");
		 	resultList.add("1, successfully logged out from the application");
			Log.info("Logout successful");
		 
	 }
	 
	
	 
	 
}

