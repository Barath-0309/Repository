package net.phpTravels.HomePageTests;

import org.testng.annotations.Test;

import net.phpTravels.reusableClass.Driver;

public class HomePageTests extends Driver {

	public HomePageTests() {
		super();
	}
	/*
	@Test (priority = 1)
	public void clickMyAccountButton() throws InterruptedException {
		
		Thread.sleep(5000);
		GetTile();
		Thread.sleep(5000);
		
	}*/
	
}
