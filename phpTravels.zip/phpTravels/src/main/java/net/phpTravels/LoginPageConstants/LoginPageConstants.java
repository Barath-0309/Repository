package net.phpTravels.LoginPageConstants;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPageConstants {

	
	/*
	 * @author: M1049895: Locators and Methods are defined in this class to access Login Page
	 * 
	 * 
	 * 
	 */
	
	private WebDriver driver;
	
	public LoginPageConstants(WebDriver driver) {
		this.driver = driver;
		
	}
	
	@FindBy (xpath = "//*[@id=\"loginfrm\"]/div[3]/div[1]/label/input")
	private WebElement emailField;
	
	@FindBy(xpath = "/html/body/div[2]/div[1]/section/div/div[1]/div[2]/form/div[3]/div[2]/label/input")
	private WebElement passwordField;
	
	
	@FindBy(xpath = ".//button[@class = 'btn btn-primary btn-lg btn-block loginbtn']")
	private WebElement LoginButton;
	
	@FindBy (xpath = "/html/body/div/div[1]/section/div/div[1]/div[2]/form/div[1]/div")
	private WebElement ErrorText; 
	
	@FindBy(xpath = "")
	private WebElement SignUpButton;
	
	@FindBy(xpath = "")
	private WebElement ForgotPasswordButton;
	
	@FindBy(xpath = " /html/body/div[2]/div[1]/div[1]/div/div/div[1]/div/div[2]/h3")
	WebElement LoginSuccess;
	
	@FindBy (xpath  = "/html/body/div/header/div[2]/div/div/div/div/nav/ul[1]/li/a")
	WebElement HomeButton;
	
	@FindBy (xpath = ".//a[contains(text(), 'Flights')]")
	WebElement FlightMenu;
	
	@FindBy (xpath = "/html/body/div[4]/div/input")
	WebElement FromField;
	//div[@id= 'select2-drop']['==$0']"
	
	@FindBy (xpath = "/html/body/div[5]/div/input")
	WebElement ToField;
	
	@FindBy(xpath = "//input[@id='FlightsDateStart']")
	WebElement DepartureDate;
	@FindBy(xpath = "/html/body/div[2]/div[9]/div/div/div[2]/div[27]")
	WebElement SelectDate;
	
	@FindBy(xpath = "//div[@class = 'col-lg-1 col-sm-12 col-xs-12']")
	WebElement SearchButton;
	
	@FindBy(xpath = "//*[@id=\"LIST\"]/li[1]/div/div[1]/div[2]/form/div[2]/div/button")
	WebElement BookButton;
	
	
	@FindBy (xpath = ".//button[@class = 'btn btn-success btn-lg btn-block completebook']")
	WebElement ConfirmBooking;
	
	@FindBy(xpath = ".//button[@id='45' or @class = 'btn btn-default arrivalpay']")
	WebElement PayOnArrival;
	
	@FindBy (xpath = ".//h4[contains (text(), 'Your booking status is Reserved')]")
	WebElement BookingStatus;
	
	@FindBy(xpath = ".//a[contains(text(), 'Hotels')]")
	WebElement HotelsMenu;
	
	@FindBy (xpath = ".//*[@class='dropdown dropdown-login dropdown-tab'] ")
	WebElement DemoDropdown;
	
	@FindBy (xpath = "//*[@class=\"dropdown-item tr\"]")
	WebElement ClickLogout;
	
	
	
	public void clickLogoutButton() {
		DemoDropdown.click();
		ClickLogout.click();
	}
	public void clickHotelsMenu() {
		//WebDriverWait wait = new WebDriverWait(driver, 10);
		
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[1]/div[1]/div[1]/div[3]/div/div/div/div/div/nav/ul/li[1]/a")));
		
		//Select objSelect = new Select(driver.findElement((By) HotelsMenu));
		//objSelect.selectByVisibleText("Hotels");
		/*
		try {
			driver.findElement(By.xpath(".//a[contains(text(), 'Hotels')]")).click();
		}catch (NoSuchElementException e) {
			System.out.println("Not Found");
		}
		*/
		
		HotelsMenu.click();
	}
	
	public String GetBookingStatus() {
		return BookingStatus.getText();
	}
	
	public void clickToAccept() {
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
//		driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(5));
		driver.switchTo().alert().accept();
	}
	public void ClickPayOnArrival() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		new WebDriverWait(driver,60).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//button[@id='45' or @class = 'btn btn-default arrivalpay']")));
		Thread.sleep(3000);
		PayOnArrival.click();
	}
	public void ClickConfirmBooking() {
		JavascriptExecutor js = (JavascriptExecutor) driver; 
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		ConfirmBooking.click();
	}
	public void clickBook() {
		BookButton.click();
	}
	public void clickSearchButton() {
		SearchButton.click();
	}
	
	public void EnterDepartureDate() {
		DepartureDate.click();
		SelectDate.click();
	}
	public void EnterToPlace(String destination) {
		ToField.click();
		ToField.sendKeys(destination);
	}
	
	public void EnterFromPlace(String orgin) {
		FromField.click();
		FromField.sendKeys(orgin);
	}
	
	public void flightMenuClick() {
		FlightMenu.click();
	}
	
	public void ClickHomeButton() {
		HomeButton.click();
	}
	
	public String loginSuccessValidation() {
		return LoginSuccess.getText();
		
	}
	
	public void clearEmailFields() {
		emailField.click();
		emailField.clear();
	}
	public void clearPasswordFields() {
		passwordField.click();
		passwordField.clear();
	}
	
	public void emailFieldValidation(String emailId) {
		emailField.sendKeys(emailId);
	}
	
	public void passwordFieldValidtion(String password1) {
		passwordField.sendKeys(password1);
	}
	
	public void loginButtonValidation() {
		LoginButton.click();
	}
	
	public void singUpButtonValidation() {
		SignUpButton.click();
	}
	
	public void forgotPasswordValidation() {
		ForgotPasswordButton.click();
	}
	
	public String errorTextValidte() {
		return ErrorText.getText();
	}
	
}
