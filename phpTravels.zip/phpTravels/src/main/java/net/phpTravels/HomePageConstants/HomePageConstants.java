package net.phpTravels.HomePageConstants;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class HomePageConstants {

	
	public WebDriver driver;
	public HomePageConstants(WebDriver driver) {
		this.driver = driver;
	}
	
	@FindBy(xpath = "/html/body/div/header/div[1]/div/div/div[2]/div/ul/li[3]/div/a")
	private WebElement MyAccountDropdown;
	
	@FindBy(xpath = "//*[@id=\"//header-waypoint-sticky\"]/div[1]/div/div/div[2]/div/ul/li[3]/div/div/div/a[1]")
	private WebElement LoginMenuButton;
	
	@FindBy (xpath = "//*[@id=\"//header-waypoint-sticky\"]/div[1]/div/div/div[1]/div/a/img")
	private WebElement TitleName;
	
	public void MyAccountDropdownValidation() {
		MyAccountDropdown.click();
	}
	public void LoginMenuClickValidate() {
		LoginMenuButton.click();
	}
	
	public void GetTitleValidate() {
		Select dropdownElement = new Select(driver.findElement((By) MyAccountDropdown));
		dropdownElement.selectByVisibleText("Login");
		}
}

