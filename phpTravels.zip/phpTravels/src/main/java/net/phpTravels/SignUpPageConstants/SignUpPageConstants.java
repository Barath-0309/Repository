package net.phpTravels.SignUpPageConstants;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SignUpPageConstants {
private WebDriver driver;
	
	public SignUpPageConstants(WebDriver driver) {
		this.driver = driver;
		
	}

	@FindBy(xpath =".//a[@class = 'dropdown-item tr']")
	WebElement SignUp;
	
	@FindBy(xpath = ".//input[@type ='text' and @name = 'firstname']")
	WebElement FirstName;
	
	@FindBy(xpath = ".//input[@type ='text' and @name = 'lastname']")
	WebElement LastName;
	
	@FindBy(xpath = ".//input[@type ='text' and @name = 'phone']")
	WebElement MobileNumber;
	
	@FindBy (xpath = ".//input[@type ='text' and @name = 'email']")
	WebElement Email;
	@FindBy(xpath = ".//input[@type ='password' and @name = 'password']")
	WebElement Password;
	@FindBy(xpath = ".//input[@type ='password' and @name = 'confirmpassword']")
	WebElement ConfirmPassword;
	
	@FindBy(xpath = "//*[@id=\"headersignupform\"]/div[8]/button")
	WebElement ClickSignUpButton;
	
	public void clickSignUpButton() {
		ClickSignUpButton.click();
	}
	
	public void clickSignUp() {
	SignUp.click();
	
	}
	
	public void enterFirstName(String firstName) {
		FirstName.sendKeys(firstName);
	}

	public void enterLastName(String lastName) {
		LastName.sendKeys(lastName);
		
		
	}
	
	public void enterMobileNumber(String mobileNumber) {
		MobileNumber.sendKeys(mobileNumber);
		
	}

	public void enterEmail(String email) {
		
		Email.sendKeys(email);
	}
	

	public void enterPassword(String password) {
	Password.sendKeys(password);	
	}

	public void enterConfirmPassword(String confirmPassword) {
		ConfirmPassword.sendKeys(confirmPassword);
	}
	
	
}


